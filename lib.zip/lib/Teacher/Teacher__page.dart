class Tteacher{

  String id;
  String name;
  int price;
  String nationality;
  int age;
  String phone;
  String imageUrl;
  String subtitel;
  String description;
  String youtubeUrl;

  Tteacher({
    required this.id,
    required this.name,
    required this.price,
    required this.nationality,
    required this.age,
    required this.phone,
    required this.imageUrl,
    required this.subtitel,
    required this.description,
    required this.youtubeUrl,

  });

}